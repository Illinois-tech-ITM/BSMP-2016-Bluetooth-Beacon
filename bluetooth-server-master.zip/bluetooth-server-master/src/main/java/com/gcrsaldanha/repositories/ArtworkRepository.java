package com.gcrsaldanha.repositories;

import com.gcrsaldanha.domain.Artwork;
import com.gcrsaldanha.domain.User;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ArtworkRepository extends MongoRepository<Artwork, String> {

    Artwork findByDvcKey(String dvcKey);

    List<Artwork> findByUser(User user);
}
