package com.gcrsaldanha.bootstrap;

import com.gcrsaldanha.domain.User;
import com.gcrsaldanha.repositories.UserRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

@Component
public class UserLoader implements ApplicationListener<ContextRefreshedEvent> {

    private UserRepository userRepository;

    private Logger log = Logger.getLogger(UserLoader.class);

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        /**
        this.userRepository.deleteAll();

        User user_00 = new User();
        user_00.setName("user_00");
        user_00.setPassword("00");
        userRepository.save(user_00);

        log.info("Saved user_00");

        User user_01 = new User();
        user_01.setName("user_01");
        user_01.setPassword("01");
        userRepository.save(user_01);

        log.info("Saved user_01");
         */
    }

}
