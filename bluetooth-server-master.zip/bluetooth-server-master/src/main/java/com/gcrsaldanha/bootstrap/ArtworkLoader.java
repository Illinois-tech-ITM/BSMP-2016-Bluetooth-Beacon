package com.gcrsaldanha.bootstrap;

import com.gcrsaldanha.domain.Artwork;
import com.gcrsaldanha.domain.Translation;
import com.gcrsaldanha.domain.User;
import com.gcrsaldanha.repositories.ArtworkRepository;
import com.gcrsaldanha.repositories.UserRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ArtworkLoader implements ApplicationListener<ContextRefreshedEvent> {

    private ArtworkRepository artworkRepository;
    private UserRepository userRepository;

    private User user_00;
    private User user_01;

    private Logger log = Logger.getLogger(ArtworkLoader.class);

    @Autowired
    public void setArtworkRepository(ArtworkRepository artworkRepository) {
        this.artworkRepository = artworkRepository;
    }

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        createUsers();
        this.artworkRepository.deleteAll();

        Artwork monaLisa = new Artwork();
        monaLisa.setDvcKey("DVC0000");
        monaLisa.setAuthorName("Leonardo da Vinci");
        monaLisa.setDvcName("Mona Lisa");
        monaLisa.setImageURL("https://dl.dropboxusercontent.com/u/75076819/mona-lisa.jpg");
        List<Translation> monaLisaTranslations = new ArrayList<>();
        monaLisaTranslations.add(createMonaLisaTranslationEnUs());
        monaLisaTranslations.add(createMonaLisaTranslationPtBr());
        monaLisa.setTranslations(monaLisaTranslations);
        monaLisa.setUser(user_00);

        artworkRepository.save(monaLisa);
        log.info("Saved Mona Lisa");

        Artwork theScream = new Artwork();
        theScream.setDvcKey("DVC0001");
        theScream.setAuthorName("Vincent van Gogh");
        theScream.setDvcName("The Starry Night");
        theScream.setImageURL("https://dl.dropboxusercontent.com/u/75076819/the-starry-night.jpg");
        List<Translation> theScreamTranslations = new ArrayList<>();
        theScreamTranslations.add(createStarryNightTranslationEnUs());
        theScreamTranslations.add(createStarryNightTranslationPtBr());
        theScream.setTranslations(theScreamTranslations);
        theScream.setUser(user_01);

        artworkRepository.save(theScream);
        log.info("Saved The Scream");
    }

    private void createUsers() {
        userRepository.deleteAll();

        user_00 = new User();
        user_00.setName("user_00");
        user_00.setPassword("00");
        userRepository.save(user_00);

        log.info("Saved user_00");

        user_01 = new User();
        user_01.setName("user_01");
        user_01.setPassword("01");
        userRepository.save(user_01);

        log.info("Saved user_01");
    }

    private Translation createMonaLisaTranslationEnUs() {
        Translation translation = new Translation();
        translation.setLanguage("en-us");
        translation.setTitle("Mona Lisa");
        translation.setContent("The Mona Lisa (/ˌmoʊnə ˈliːsə/; Italian: Monna Lisa [ˈmɔnna ˈliːza] or La Gioconda [la dʒoˈkonda], French: La Joconde [la ʒɔkɔ̃d]) is a half-length portrait of a woman by the Italian artist Leonardo da Vinci, which has been acclaimed as \"the best known, the most visited, the most written about, the most sung about, the most parodied work of art in the world\".");
        return translation;
    }

    private Translation createMonaLisaTranslationPtBr() {
        Translation translation = new Translation();
        translation.setLanguage("pt-br");
        translation.setTitle("Mona Lisa");
        translation.setContent("Mona Lisa (\"Senhora Lisa\"[2] ) também conhecida como A Gioconda[3] (em italiano: La Gioconda, \"a sorridente\"[4] ; em francês, La Joconde) ou ainda Mona Lisa del Giocondo (\"Senhora Lisa [esposa] de Giocondo\") é a mais notável e conhecida obra de Leonardo da Vinci");
        return translation;
    }

    private Translation createStarryNightTranslationEnUs() {
        Translation translation = new Translation();
        translation.setLanguage("en-us");
        translation.setTitle("The Starry Night");
        translation.setContent("The Starry Night is an oil on canvas by the Dutch post-impressionist painter Vincent van Gogh. Painted in June 1889, it depicts the view from the east-facing window of his asylum room at Saint-Rémy-de-Provence, just before sunrise, with the addition of an idealized village.");
        return translation;
    }

    private Translation createStarryNightTranslationPtBr() {
        Translation translation = new Translation();
        translation.setLanguage("pt-br");
        translation.setTitle("A Noite Estrelada");
        translation.setContent("A Noite Estrelada (em neerlandês: De sterrennacht) é uma das mais conhecidas pinturas do artista holandês pós-impressionista Vincent van Gogh.");
        return translation;
    }
}
