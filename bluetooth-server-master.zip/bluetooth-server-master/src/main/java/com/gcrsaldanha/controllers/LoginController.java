package com.gcrsaldanha.controllers;

import com.gcrsaldanha.SpringApplication;
import com.gcrsaldanha.domain.User;
import com.gcrsaldanha.services.SecureLoginService;
import com.gcrsaldanha.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
public class LoginController {

    @Autowired
    SecureLoginService loginService;
    @Autowired
    UserService userService;

    @RequestMapping(value = "/authenticate", method = RequestMethod.GET)
    public ResponseEntity<Void> authenticate(@RequestHeader("name") String name,
                                             @RequestHeader("password") String password) {
        HttpHeaders httpHeaders = new HttpHeaders();
        HttpStatus httpStatus;
        User loginUser = new User();
        loginUser.setName(name);
        loginUser.setPassword(password);
        if(loginService.authenticateUser(loginUser)) {
            User user = userService.findByName(loginUser.getName());
            String sessionId = loginService.generateToken();
            httpHeaders.add("sessionId", sessionId);
            httpHeaders.add("Access-Control-Expose-Headers", "sessionId");
            httpStatus = HttpStatus.OK;
            saveSession(user, sessionId);
        } else {
            httpStatus = HttpStatus.BAD_REQUEST;
            httpHeaders.add("message", "Invalid Credentials");
        }
        return new ResponseEntity<Void>(httpHeaders, httpStatus);
    }

    private void saveSession(User user, String sessionId) {
        SpringApplication.addUserToSession(user, sessionId);
    }
}
