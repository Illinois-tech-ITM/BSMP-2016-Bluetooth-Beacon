package com.gcrsaldanha.controllers;

import com.gcrsaldanha.SpringApplication;
import com.gcrsaldanha.domain.Artwork;
import com.gcrsaldanha.domain.User;
import com.gcrsaldanha.services.ArtworkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
public class ArtworkController {

    @Autowired
    private ArtworkService artworkService;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    @ResponseBody
    String home() {
        return "Hello World!";
    }

    @RequestMapping(value = "/getArtwork", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public ResponseEntity<Artwork> getArtwork(@RequestParam("dvcKey") String dvcKey) {
        Artwork artwork = artworkService.findByDvcKey(dvcKey);
        return new ResponseEntity<>(artwork, HttpStatus.OK);
    }

    @RequestMapping(value = "/getArtworks", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public ResponseEntity<List<Artwork>> getArtworks() {
        List<Artwork> artworks = artworkService.findAll();
        return new ResponseEntity<>(artworks, HttpStatus.OK);
    }

    @RequestMapping(value = "/getArtworksByUser", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public ResponseEntity<List<Artwork>> getArtworksByUser(@RequestHeader("sessionId") String sessionId) {
        User user = SpringApplication.getUserBySessionToken(sessionId);
        HttpStatus httpStatus;
        List<Artwork> artworks = null;
        if(user != null) {
            artworks = artworkService.findByUser(user);
            httpStatus = HttpStatus.OK;
        } else {
            httpStatus = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(artworks, httpStatus);
    }

    @RequestMapping(value = "/addOrUpdateArtwork", method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<Void> addOrUpdateArtwork(@RequestBody Artwork artwork,
                                                   @RequestHeader("sessionId") String sessionId) {
        User user = SpringApplication.getUserBySessionToken(sessionId);
        HttpStatus httpStatus;
        if(user != null) {
            artwork.setUser(user);
            artworkService.addOrUpdate(artwork);
            httpStatus = HttpStatus.OK;
        } else {
            httpStatus = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<Void>(new HttpHeaders(), httpStatus);
    }

    //TODO: verify if the dvcKey BELONGS to the logged User.
    @RequestMapping(value = "/deleteArtwork", method = RequestMethod.DELETE)
    public ResponseEntity<Void> deleteArtwork(@RequestParam("dvcKey") String dvcKey,
                                              @RequestHeader("sessionId") String sessionId) {
        HttpStatus httpStatus;
        String message;
        HttpHeaders httpHeaders = new HttpHeaders();
        User user = SpringApplication.getUserBySessionToken(sessionId);
        if(user == null) {
            httpStatus = HttpStatus.BAD_REQUEST;
            message = "Invalid credentials";
            httpHeaders.add("message", message);
            return new ResponseEntity<Void>(httpHeaders, httpStatus);
        }

        Artwork foundArtwork = artworkService.findByDvcKey(dvcKey);
        if (foundArtwork == null) {
            httpStatus = HttpStatus.NOT_FOUND;
            message = "This Artwork was not found.";
        } else {
            httpStatus = HttpStatus.OK;
            message = "The Artwork with dvcKey " + foundArtwork.getDvcKey() + " was deleted.";
            artworkService.delete(foundArtwork);
        }
        httpHeaders.add("message", message);
        return new ResponseEntity<Void>(httpHeaders, httpStatus);
    }

}

// TODO: Refactor sessionId verification. Don't Repeat Yourself principle.
