package com.gcrsaldanha.controllers;

import com.gcrsaldanha.domain.User;
import com.gcrsaldanha.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/getUsers", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public ResponseEntity<List<User>> getUsers() {
        List<User> users = userService.findAll();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @RequestMapping(value = "/getUser", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public ResponseEntity<User> getUser(@RequestParam("name") String name) {
        User user = userService.findByName(name);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

    @RequestMapping(value = "/addUser", method = RequestMethod.POST, consumes = "application/json")
    public ResponseEntity<Void> addUser(@RequestBody User user) {
        String message;
        HttpStatus httpStatus;

        User existentUser = userService.findByName(user.getName());
        if(existentUser != null) {
            httpStatus = HttpStatus.CONFLICT;
            message = "User already exists";
        } else {
            httpStatus = HttpStatus.OK;
            message = "User created";
            userService.save(user);
        }
        return new ResponseEntity<>(new HttpHeaders(), httpStatus);
    }
}
