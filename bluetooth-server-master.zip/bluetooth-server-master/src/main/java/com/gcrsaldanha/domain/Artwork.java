package com.gcrsaldanha.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "artworks")
public class Artwork {

    @Id
    private String id;
    @DBRef
    private User user;

    private String dvcKey;
    private String authorName;
    private String dvcName;
    private String imageURL;
    private List<Translation> translations;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getDvcKey() {
        return dvcKey;
    }

    public void setDvcKey(String dvcKey) {
        this.dvcKey = dvcKey;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getDvcName() {
        return dvcName;
    }

    public void setDvcName(String dvcName) {
        this.dvcName = dvcName;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public List<Translation> getTranslations() {
        return translations;
    }

    public void setTranslations(List<Translation> translations) {
        this.translations = translations;
    }
}
