package com.gcrsaldanha;

import com.gcrsaldanha.domain.User;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashMap;

@SpringBootApplication
public class SpringApplication {

    //TODO: persist this code? Or put it elsewhere..
    private static HashMap<String, User> sessionUsers = new HashMap<>();

    private static void resetSession() {
        sessionUsers.clear();
    }

    public static void addUserToSession(User sessionUser, String sessionToken) {
        sessionUsers.put(sessionToken, sessionUser);
    }

    public static User getUserBySessionToken(String sessionToken) {
        return sessionUsers.get(sessionToken);
    }

    public static void removeUserFromSession(String sessionUserToken) {
        sessionUsers.remove(sessionUserToken);
    }

    public static void main(String[] args) {
        resetSession();
        org.springframework.boot.SpringApplication.run(SpringApplication.class, args);
    }
}
