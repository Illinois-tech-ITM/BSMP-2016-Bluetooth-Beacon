package com.gcrsaldanha.services;

import com.gcrsaldanha.domain.Artwork;
import com.gcrsaldanha.domain.User;

import java.util.List;

public interface ArtworkService {

    Artwork findByDvcKey(String dvcKey);

    void addOrUpdate(Artwork artwork);

    void delete(Artwork artwork);

    List<Artwork> findAll();

    List<Artwork> findByUser(User user);
}
