package com.gcrsaldanha.services;

import com.gcrsaldanha.domain.User;

public interface SecureLoginService {

    User findByName(String name);

    boolean authenticateUser(User userLogin);

    String generateToken();
}
