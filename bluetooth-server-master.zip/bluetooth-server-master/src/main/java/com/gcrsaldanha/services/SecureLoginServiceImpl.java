package com.gcrsaldanha.services;

import com.gcrsaldanha.domain.User;
import com.gcrsaldanha.repositories.UserRepository;
import com.gcrsaldanha.utilities.SessionIdentifierGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SecureLoginServiceImpl implements SecureLoginService {

    @Autowired
    UserRepository userRepository;

    @Override
    public User findByName(String name) {
        User user = userRepository.findByName(name);
        return user;
    }

    @Override
    public String generateToken() {
        return SessionIdentifierGenerator.sessionId();
    }

    //TODO: Abstract this to a Response
    @Override
    public boolean authenticateUser(User userLogin) {
        User savedUser = findByName(userLogin.getName());
        if(!userExists(savedUser)) {
            return false;
        } else {
            if(!userPasswordMatches(userLogin, savedUser)) {
                return false;
            }
        }
        return true;
    }

    private boolean userExists(User candidateUser) {
        if(candidateUser == null) {
            return false;
        } else {
            return true;
        }
    }

    private boolean userPasswordMatches(User candidate, User savedUser) {
        return candidate.getPassword().equals(savedUser.getPassword());
    }
}
