package com.gcrsaldanha.services;

import com.gcrsaldanha.domain.Artwork;
import com.gcrsaldanha.domain.User;
import com.gcrsaldanha.repositories.ArtworkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArtworkServiceImpl implements ArtworkService {

    @Autowired
    private ArtworkRepository artworkRepository;
    @Autowired
    private UserService userService;

    @Override
    public Artwork findByDvcKey(String dvcKey) {
        Artwork artwork = artworkRepository.findByDvcKey(dvcKey);
        return artwork;
    }

    @Override
    public void addOrUpdate(Artwork artwork) {
        Artwork oldArtwork = artworkRepository.findByDvcKey(artwork.getDvcKey());
        if (oldArtwork != null) {
            artwork.setId(oldArtwork.getId());
        }
        artworkRepository.save(artwork);
    }

    @Override
    public void delete(Artwork artwork) {
        artworkRepository.delete(artwork);
    }

    @Override
    public List<Artwork> findAll () {
        return artworkRepository.findAll();
    }

    @Override
    public List<Artwork> findByUser(User user) {
        User savedUser = userService.findByName(user.getName());
        return artworkRepository.findByUser(savedUser);
    }
}
