package com.gcrsaldanha.services;

import com.gcrsaldanha.domain.User;

import java.util.List;

public interface UserService {

    User findByName(String name);

    List<User> findAll();

    void save(User user);

}
