package com.gcrsaldanha.utilities;

import java.math.BigInteger;
import java.security.SecureRandom;

// TODO: refactor where this class is placed
public class SessionIdentifierGenerator {
    public static SecureRandom random = new SecureRandom();

    public static String sessionId() {
        return new BigInteger(130, random).toString(32);
    }
}
